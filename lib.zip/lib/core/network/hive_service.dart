import 'package:hive_flutter/adapters.dart';
import 'package:path_provider/path_provider.dart';
import 'package:student_management/app/constant/hive_table_constant.dart';
import 'package:student_management/features/batch/data/model/batch_hive_model.dart';

class HiveService {
  Future<void> int() async {
    //Initialize hive
    var directory = await getApplicationDocumentsDirectory(); // from the path provide
    //since andriod and iphone have different path file
    var path = '${directory.path}/student_management_starter_new.db';

    Hive.init(path);

    //Register adapter
    Hive.registerAdapter(BatchHiveModelAdapter());
  }

  //Batch queries
  Future<void> addBatch(BatchHiveModel batch) async {
    var box = await Hive.openBox<BatchHiveModel>(HiveTableConstant.batchBox);
    await box.put(batch.batchId, batch);
  }

  Future<void> deleteBatch(String id) async {
    var box = await Hive.openBox<BatchHiveModel>(HiveTableConstant.batchBox);
    await box.delete(id);
  }

  Future<List<BatchHiveModel>> getAllBatches() async {
    var box = await Hive.openBox<BatchHiveModel>(HiveTableConstant.batchBox);
    return box.values.toList()
      ..sort((a, b) => a.batchName.compareTo(b.batchName),
      );
  }


}
