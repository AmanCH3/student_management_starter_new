import 'package:student_management/core/network/hive_service.dart';
import 'package:student_management/features/batch/data/model/batch_hive_model.dart';
import 'package:student_management/features/batch/domain/entity/batch_entity.dart';
import 'package:student_management/features/batch/domain/repository/batch_repository.dart';

import '../batch_data_source.dart';

class BatchLocalDataSource implements IBatchDataSource {

  final HiveService _hiveService ;

  //Dependencies injection
  BatchLocalDataSource({required HiveService hiveService})
      : _hiveService = hiveService ;
  @override
  Future<void> createBatch(BatchEntity entity)  async{
    try {
      // convert Entity to model
      final batchHiveModel = BatchHiveModel.fromEntity(entity) ;

      await _hiveService.addBatch(batchHiveModel) ;


    }
    catch(e){
      throw Exception(e);
    }
  }

  @override
  Future<void> deleteBatch(String id) async {
    try {
      await _hiveService.deleteBatch(id) ;
    }
    catch (e){
      throw Exception(e) ;
    }
  }

  @override
  Future<List<BatchEntity>> getBatches()  async{
    try {
      //convert each  hive model to entity
      return _hiveService.getAllBatches().then((value){
        return value.map((single) => single.toEntity()).toList() ;
      }) ;

    }
    catch(e){
      throw Exception(e) ;
    }
  }

}

